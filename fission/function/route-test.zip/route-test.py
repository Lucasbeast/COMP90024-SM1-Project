import json

from flask import current_app, request


def main():
    data = request.get_json(force=True)
    name = data['name']
    return json.dumps({f"name:{name}"})
