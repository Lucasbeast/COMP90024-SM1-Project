from flask import Flask, request, jsonify
from elasticsearch8 import Elasticsearch

app = Flask(__name__)

# Initialize Elasticsearch client
es_client = Elasticsearch(
    'https://elasticsearch-master.elastic.svc.cluster.local:9200',
    basic_auth=("elastic", "elastic"),
    verify_certs=False,
    ssl_show_warn=False
)


def get_index_size(client, index_name):
    response = client.count(index=index_name)
    if 'count' in response:
        return response['count']
    else:
        raise ValueError("Failed to get index size")


def fetch_all_docs(client, index_name):
    index_size = get_index_size(client, index_name)
    query = {"size": index_size, "query": {"match_all": {}}}
    response = client.search(index=index_name, body=query)
    return response['hits']['hits']


@app.route('/fetch-all', methods=['POST'])
def main():
    print("Received Request:", request.data)
    data = request.get_json()
    print("Parsed JSON:", data)
    if data and 'index' in data:
        index_name = data.get('index')
        try:
            documents = fetch_all_docs(es_client, index_name)
            return jsonify(documents)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Missing index parameter"}), 400


if __name__ == '__main__':
    app.run(debug=True)
