from elasticsearch8 import Elasticsearch


def main():
    client = Elasticsearch(
        'https://elasticsearch-master.elastic.svc.cluster.local:9200',
        http_auth=("elastic", "elastic"),
        verify_certs=False,
        ssl_show_warn=False
    )
    if client:
        return 'True'
    else:
        return 'False'
